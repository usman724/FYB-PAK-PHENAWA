const mysql = require('mysql');


function selectQueryWithParams(sqlQuery , values){

  return new Promise((resolve,reject)=>{

    connection.getConnection((error,connection)=>{
      if(error){
        return reject(error);
      }else {
        if(connection){
          connection.query(sqlQuery, values , (error,results,fields)=>{
            connection.release();
            if(error){
                return reject(error);
            }
              return resolve(results);
          });
        }
      }// if - else ends here
    });

  });
}// methods ends here

function selectQuery(sqlQuery,callback){
  return new Promise((resolve,reject)=>{
    connection.getConnection((error,connection)=>{
      if(error){
        return reject(error);
      }else {
        if(connection){
          connection.query(sqlQuery , (error,results)=>{
            connection.release();
            if(error){

              return reject(error);
            }
            return callback(null,results);
          });
        }
      }// if - else ends here
    });
  });
}// methods ends here

function insertQuery(sqlQuery, params){
  return new Promise((resolve,reject)=>{
    connection.getConnection((error,connection)=>{
      if(error){
        return reject(error);
      }else{
        connection.query(sqlQuery, params , (error,results,fields)=>{
          connection.release();
          if(error){
            return reject(error);
          }
          return resolve(results);
        });
      }
    });
  });
}



function select(sqlQuery){
  return new Promise((resolve,reject)=>{
    connection.getConnection((error,connection)=>{
      if(error){
        return reject(error);
      }else{
        connection.query(sqlQuery, (error,results,fields)=>{
          connection.release();
          if(error){
            return reject(error);
          }
          return resolve(results);
        });
      }
    });
  });
}

// method ends here

module.exports = {
  selectQueryWithParams : selectQueryWithParams,
  selectQuery : selectQuery,
  insertQuery : insertQuery,
  select: select
};
