const express = require('express');
const app =express();
const path = require('path');
const moment = require('moment');
const dateFormat = require('dateformat');
var NodeGeocoder = require('node-geocoder');
const multer = require('multer');
var jwt = require('jsonwebtoken');
var DateDiff = require('date-diff');
const dbConnection = require('./DbConnection/dbconnection');
const util = require('util');

let loginUserID;
let loginUserName;
let loginUserImage;
let SelectTailorID;
let SelectTailorName;
let  loginUserpass;
let nowTime= Date.now();

let nowTimer=dateFormat(nowTime, "dddd, mmmm dS, yyyy, h:MM:ss TT");


//const mysql = require('mysql');
const bodyParser = require('body-parser');
//let MySQLEvents = require('mysql-events');
//const validator = require('express-validator');
const expressValidator = require('express-validator');

app.use(express.static(__dirname + '/public')); // Public folder is use to style the website..
app.use(bodyParser.urlencoded({extended:true}));
app.set('views', path.join(__dirname, 'views/pages'));
app.set('view engine','ejs');
app.use(bodyParser.json());
app.use(expressValidator());
//var absolutePath = path.resolve(__dirname+'/views/pages');
//const {check,validationResult} = require('express-validator/check');
//const {matchedData ,sanitize} = require('express-validator/filter');

var appc = require('http').Server(app),
  io = require('socket.io').listen(appc),
  fs = require('fs'),
  mysql = require('mysql'),
  connectionsArray = [],

  connection = mysql.createConnection({
    connectionLimit:'10',
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'fyp',
    port: 3306
  }),

  POLLING_INTERVAL = 3000,
  pollingTimer;

  var connections = require('express-myconnection'),
    mysqli = require('mysql');


  
app.use(

  connections(mysqli,{
      host     : 'localhost',
      user     : 'root',
      password : '',
      database : 'fyp',
      debug    : false //set true if you wanna see debug logger
  },'request')

);


// If there is an error connecting to the database
connection.connect(function(err) {
    // connected! (unless `err` is set)
    if (err) {
      console.log(err);
    }
  });

  // creating the server ( localhost:8000 )
  appc.listen(3000,()=>{
    console.log('Listining at port 3000');
  });


  /*
   *
   * HERE IT IS THE COOL PART
   * This function loops on itself since there are sockets connected to the page
   * sending the result of the database query after a constant interval
   *
   */


 // var now = moment();
  var pollingLoop = function() {

    // Doing the database query
  //  console.log("here login user id "+loginUserID)
    var query = connection.query('SELECT * FROM notification where reciverid='+loginUserID);
      // console.log(moment().startOf('day').fromNow());
     //  var a = moment([2019, 11, 28]);
    //  var b = moment([2019, 11, 28]);
   // console.log(moment([2019, 11, 28]).toNow(true)) // "a day ago"


     users=[]; // this array will contain the result of our db query

    // setting the query listeners
    query
      .on('error', function(err) {
        // Handle error, and 'end' event will be emitted after this as well
     //  console.log(err);
        updateSockets(err);
      })
      .on('result', function(user) {

        // it fills our array looping on each user row inside the db
        users.push(user);
      })
      .on('end', function() {
        // loop on itself only if there are sockets still connected
        if (connectionsArray.length) {

          pollingTimer = setTimeout(pollingLoop, POLLING_INTERVAL);

          updateSockets({
            users: users
          });
        } else {

   //       console.log('The server timer was stopped because there are no more socket connections on the appc')

        }
      });
  };


  // creating a new websocket to keep the content updated without any AJAX request
  io.sockets.on('connection', function(socket) {

    //console.log('Number of connections:' + connectionsArray.length);
    // starting the loop only if at least there is one user connected
    if (!connectionsArray.length) {
      pollingLoop();
    }

    socket.on('disconnect', function() {
      var socketIndex = connectionsArray.indexOf(socket);
    //  console.log('socketID = %s got disconnected', socketIndex);
      if (~socketIndex) {
        connectionsArray.splice(socketIndex, 1);
      }
    });

    console.log('A new socket is connected!');
    connectionsArray.push(socket);

  });


  var updateSockets = function(data) {
    // adding the time of the last update

    data.time = new Date();
   // console.log('Pushing new data to the clients connected ( connections amount = %s ) - %s',
     //connectionsArray.length , data.time);

    // sending new data to all the sockets connected
    connectionsArray.forEach(function(tmpSocket) {
      tmpSocket.volatile.emit('notification', data);
    });
  };

  //console.log('Please use your browser to navigate to http://localhost:8000');


app.get('/login/index',(req,res)=>{
  console.log('/login/index');
    fs.readFile(res.render('index.ejs'),function(err, data){
        if (err) {
          console.log(err);
          res.writeHead(500);
          return res.end('Error loading check.html');
        }
        res.writeHead(200);

        res.end(data);
      });


})

// function authenticationfun(req,res,next){
//   const authHeader = req.header['authorization'];
//   const token = authHeader && authHeader.split(' ')[1]
//   if(!Token) return res.status(401).send('Access Denied');

//   try{

//       jwt.verify(token,'shhhhh',(err ,user)=>{
//           if(err) return res.sendStatus(403)
//           req.user = user
//           next();
//       });
      
//   }catch{
//       res.status(400).send('Invalid Token');
//   }
// }


// app.get('checkjwt',(req,res)=>{
//   var token = jwt.sign({ foo: 'bar' }, 'shhhhh');
//   res.json('auth-token',token).send(token);
// });


app.get('/signIn',(req,res)=>{


  //console.log(dateFormat(1575024968812, "dddd, mmmm dS, yyyy, h:MM:ss TT"));

  res.render('./login.ejs');
})



app.post('/Tailor',(req,res)=>{

  //console.log(dateFormat(1575024968812, "dddd, mmmm dS, yyyy, h:MM:ss TT"));
res.redirect('http://localhost:8000/pakphenawa');

})


app.post('/index',(req,res)=>{


  //console.log(req.body.Username +"   and                          "+req.body.Password);
connection.query('SELECT * FROM login WHERE name = ? AND password = ?', [req.body.Username, req.body.Password],(error,res2,field)=>{




   


  console.log(res2[0].type);
 loginUserID=res2[0].id;
 loginUserName=res2[0].name;
 loginUserpass=res2[0].password;
 loginUserImage=res2[0].imageaddress;
   let totalOrdersend=0;
   let penddingordersend=0;
   let totalTailorattach=0;


connection.query("SELECT * FROM `order`  where tailorid="+loginUserID,(error,res3,field)=>{

   for(var i = 0; i < res3.length;i++){


         //pendding
        if(res3[i].orderStatus==="confirm"){
            penddingordersend++;
        }

      totalOrdersend++;
  }


connection.query("SELECT * FROM `history`  where tailorid="+loginUserID,(error,res4,field)=>{

           totalTailorattach=res4.length;

  //    res.redirect('http://localhost:3000/login');

  connection.query("SELECT rate FROM `rating`  where tailorid="+loginUserID,(error,res5,field)=>{
       let avgrate=0;   

    for(var i = 0; i < res5.length;i++){
          avgrate=avgrate+res5[i].rate;
      }

       avgrate=avgrate/res5.length;





if(res2.length > 0 ){

//  if(res2[0].type=="u"){

//console.log('wellcome to users ');


     totalOrder=totalOrdersend;
   penddingorder=penddingordersend;
   totalTailor=totalTailorattach;
   avgratestar=avgrate;


  //  var token = jwt.sign({ username:res2[0].name }, 'shhhhh');
  //  res.header('Authorization',token);


  res.render('index',{
    "Username":res2[0].name,
    "type":res2[0].type,
    "imageaddress":res2[0].imageaddress ,
     "totalOrdersend":totalOrdersend ,
     "penddingordersend":penddingordersend ,
     "totalTailorattach":totalTailorattach ,
     "avgrate":avgrate


  });

}
 })
})


})
});
})

  let totalOrder=0;
   let penddingorder=0;
   let totalTailor=0;
   let avgratestar=0;

app.post('/dashbord',(req,res)=>{


connection.query('SELECT * FROM login WHERE name = ? AND password = ?', [loginUserName,  loginUserpass],(error,res2,field)=>{


   let totalOrdersend=0;
   let penddingordersend=0;
   let totalTailorattach=0;


connection.query("SELECT * FROM `order`  where tailorid="+loginUserID,(error,res3,field)=>{

   for(var i = 0; i < res3.length;i++){


         //pendding
        if(res3[i].orderStatus==="confirm"){
            penddingordersend++;
        }

      totalOrdersend++;
  }


connection.query("SELECT * FROM `history`  where tailorid="+loginUserID,(error,res4,field)=>{

           totalTailorattach=res4.length;

  //    res.redirect('http://localhost:3000/login');

  connection.query("SELECT rate FROM `rating`  where tailorid="+loginUserID,(error,res5,field)=>{
       let avgrate=0;

    for(var i = 0; i < res5.length;i++){
          avgrate=avgrate+res5[i].rate;
      }

       avgrate=avgrate/res5.length;






if(res2.length > 0 ){

//  if(res2[0].type=="u"){

//console.log('wellcome to users ');

  res.render('index',{
    "Username":res2[0].name,
    "type":res2[0].type,
    "imageaddress":res2[0].imageaddress ,
     "totalOrdersend":totalOrdersend ,
     "penddingordersend":penddingordersend ,
     "totalTailorattach":totalTailorattach ,
     "avgrate":avgrate


  });

}
 })
})


})
});

})

//completehistory

app.post('/history',(req,res)=>{
   connection.query("SELECT * FROM history  where tailorid="+loginUserID,(error,res2,field)=>{
         res.render('history.ejs',{
            "result":res2,
            "Username":loginUserName,
            "imageaddress":loginUserImage
        });
        });
})


// Here Route start 

app.get('/service',(req,res)=>{
  connection.query('SELECT * FROM tailorprofile  where loginid = ? AND catagory != ?', [loginUserID, 'extra'], (error,res3,field)=>{
     // console.log(util.inspect(res3, false, null, true /* enable colors */))
     connection.query('SELECT * FROM tailorprofile  where  loginid = ? AND catagory = ?', [loginUserID, 'extra'], (error,extra,field)=>{
       
     
      res.render('serviceProvide.ejs', {
           msg:"",
          "result":res3,
          "Username":loginUserName,
          "extraResult":extra ,
          "imageaddress":loginUserImage ,
        });
      
     
     
      })
       })
   
});

app.post('/services',(req,res)=>{
  connection.query('SELECT * FROM tailorprofile  where  loginid = ? AND type = ? AND catagory != ?', [loginUserID, '0', 'extra'], (error,res3,field)=>{
   
    connection.query('SELECT * FROM tailorprofile  where  loginid = ? AND catagory = ? AND type = ?', [loginUserID, 'extra', '0'], (error,extra,field)=>{
     
      res.render('serviceProvide.ejs', {
           msg:"",
          "result":res3,
          "Username":loginUserName,
          "extraResult":extra ,
          "imageaddress":loginUserImage ,
        });
    
      })

       })
   
});


app.post('/Servicem',(req,res)=>{
  connection.query('SELECT * FROM tailorprofile  where  loginid = ? AND type = ? AND catagory != ? ', [loginUserID, '1','extra'], (error,res3,field)=>{
    connection.query('SELECT * FROM tailorprofile  where  loginid = ? AND catagory = ? AND type = ?', [loginUserID, 'extra', '1'], (error,extra,field)=>{
       
     
      res.render('serviceProvide.ejs', {
           msg:"",
          "result":res3,
          "Username":loginUserName,
          "extraResult":extra ,
          "imageaddress":loginUserImage ,
        });
      
     
     
      })

       })
   
});



app.post('/serviced',(req,res)=>{

  connection.query("Delete  FROM `tailorprofile`  where profileid="+req.body.deleteId,(error,res2,field)=>{
          if(req.body.deleteuser==='1'){
            connection.query('SELECT * FROM tailorprofile  where  loginid = ? AND catagory != ? AND type = ?', [loginUserID,'extra','1'], (error,res3,field)=>{
      
              connection.query('SELECT * FROM tailorprofile  where  loginid = ? AND catagory = ? AND type = ?', [loginUserID, 'extra', '1'], (error,extra,field)=>{
       
     
                res.render('serviceProvide.ejs', {
                     msg:"",
                    "result":res3,
                    "Username":loginUserName,
                    "extraResult":extra ,
                    "imageaddress":loginUserImage ,
                  });
                
               
               
                })
             
        
              })
          }
          if(req.body.deleteuser==='0'){
            connection.query('SELECT * FROM tailorprofile  where  loginid = ? AND catagory != ? AND type = ?', [loginUserID,'extra','0'], (error,res3,field)=>{
      
              connection.query('SELECT * FROM tailorprofile  where  loginid = ? AND catagory = ? AND type = ?', [loginUserID, 'extra', '0'], (error,extra,field)=>{
       
     
                res.render('serviceProvide.ejs', {
                     msg:"",
                    "result":res3,
                    "Username":loginUserName,
                    "extraResult":extra ,
                    "imageaddress":loginUserImage ,
                  });
                
               
               
                })
             
        
              })
          }
       });
});





const storage = multer.diskStorage({
  destination: './public/images/faces',
  filename: function(req, file, cb){
    cb(null,file.originalname);
  }
});

function checkFileType(file, cb){
  // Allowed ext
  const filetypes = /jpeg|jpg|png|gif/;
  // Check ext
  const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
  // Check mime
  const mimetype = filetypes.test(file.mimetype);

  if(mimetype && extname){
    return cb(null,true);
  } else {
    cb('Error: Images Only!');
  }
}



const upload = multer({
  storage: storage,
  limits:{fileSize: 9000000},
  fileFilter: function(req, file, cb){
    checkFileType(file, cb);
  }
}).single('file');


app.post('/UploadFile', (req, res) => {
upload(req, res, (err) => {
  if(err){
    res.render('serviceProvide.ejs', {
      "result":"",
      "Username":loginUserName,
      "imageaddress":loginUserImage ,
      msg: err
    });
  } else {
    if(req.file == undefined){
      res.render('serviceProvider.ejs', {
        "result":"",
        "Username":loginUserName,
        "imageaddress":loginUserImage ,
        msg: 'Error: No File Selected!'
      });
    } else {
      var values = [loginUserID,req.body.name,req.body.price,req.file.originalname,req.body.Category,req.body.type];

                console.log(values);
          connection.query("INSERT INTO `tailorprofile` (`loginid`,`name`, `price`, `image`, `catagory`, `type` ) VALUES (?)", [values],
            (error,res2,field)=>{
            //  if(!error){
            //       res.render('serviceProvide.ejs',{
            //         "result":"",
            //         "Username":loginUserName,
            //         "imageaddress":loginUserImage ,
            //         msg: 'Uploaded!'
         
            //       })
            //    }

               if(error){
                res.render('serviceProvide.ejs',{
                  "result":"",
                  "Username":loginUserName,
                  "imageaddress":loginUserImage ,
                  msg: 'error in sub' 
       
                });
              }
              
              if(req.body.deleteuser==='1'){
                connection.query('SELECT * FROM tailorprofile  where  loginid = ? AND type = ? AND catagory != ?', [loginUserID, '1','extra'], (error,res3,field)=>{
          
                  connection.query('SELECT * FROM tailorprofile  where  loginid = ? AND catagory = ? AND type = ?', [loginUserID, 'extra', '1'], (error,extra,field)=>{
           
         
                    res.render('serviceProvide.ejs', {
                         msg:"",
                        "result":res3,
                        "Username":loginUserName,
                        "extraResult":extra ,
                        "imageaddress":loginUserImage ,
                      });
                    
                   
                   
                    })
                 
            
                  })
              }
              if(req.body.deleteuser==='0'){
                connection.query('SELECT * FROM tailorprofile  where  loginid = ? AND type = ? AND catagory != ?', [loginUserID, '0' ,'extra'], (error,res3,field)=>{
          
                  connection.query('SELECT * FROM tailorprofile  where  loginid = ? AND catagory = ? AND type = ?', [loginUserID, 'extra', '0'], (error,extra,field)=>{
           
         
                    res.render('serviceProvide.ejs', {
                         msg:"",
                        "result":res3,
                        "Username":loginUserName,
                        "extraResult":extra ,
                        "imageaddress":loginUserImage ,
                      });
                    
                   
                   
                    })
                 
            
                  })
              }
         });
    }}
  })


});



app.post('/addExtraFile', (req, res) => {
  upload(req, res, (err) => {
    if(err){
      res.render('serviceProvide.ejs', {
        "result":"",
        "Username":loginUserName,
        "imageaddress":loginUserImage ,
        msg: err
      });
    } else {
      if(req.file == undefined){
        res.render('serviceProvider.ejs', {
          "result":"",
          "Username":loginUserName,
          "imageaddress":loginUserImage ,
          msg: 'Error: No File Selected!'
        });
      } else {
        var values = [loginUserID,req.body.name,req.body.price,req.file.originalname,'extra',req.body.type];
  
                  console.log(values);
            connection.query("INSERT INTO `tailorprofile` (`loginid`,`name`, `price`, `image`, `catagory`, `type` ) VALUES (?)", [values],
              (error,res2,field)=>{
              //  if(!error){
              //       res.render('serviceProvide.ejs',{
              //         "result":"",
              //         "Username":loginUserName,
              //         "imageaddress":loginUserImage ,
              //         msg: 'Uploaded!'
           
              //       })
              //    }
  
                 if(error){
                  res.render('serviceProvide.ejs',{
                    "result":"",
                    "Username":loginUserName,
                    "imageaddress":loginUserImage ,
                    msg: 'error in sub' 
         
                  });
                }
                
                if(req.body.type==='1'){
                  connection.query('SELECT * FROM tailorprofile  where  loginid = ? AND type = ? AND catagory != ?', [loginUserID, '1','extra'], (error,res3,field)=>{
            
                    connection.query('SELECT * FROM tailorprofile  where  loginid = ? AND catagory = ? AND type = ?', [loginUserID, 'extra', '1'], (error,extra,field)=>{
             
           
                      res.render('serviceProvide.ejs', {
                           msg:"",
                          "result":res3,
                          "Username":loginUserName,
                          "extraResult":extra ,
                          "imageaddress":loginUserImage ,
                        });
                      
                     
                     
                      })
                   
              
                    })
                }
                if(req.body.type==='0'){
                  connection.query('SELECT * FROM tailorprofile  where  loginid = ? AND type = ? AND catagory != ?', [loginUserID, '0','extra'], (error,res3,field)=>{
            
                    connection.query('SELECT * FROM tailorprofile  where  loginid = ? AND catagory = ? AND type = ?', [loginUserID, 'extra', '0'], (error,extra,field)=>{
             
           
                      res.render('serviceProvide.ejs', {
                           msg:"",
                          "result":res3,
                          "Username":loginUserName,
                          "extraResult":extra ,
                          "imageaddress":loginUserImage ,
                        });
                      
                     
                     
                      })
                   
              
                    })
                }
           });
      }}
    })
  
  
  });
  
// app.post('/service', (req, res) => {

//   console.log('Object here :      '+req);
  
// //console.log(util.inspect(myObject, false, null, true /* enable colors */))



//   var data = {
//     loginid:loginUserID,  
//     name:req.body.name,
//     price:req.body.price,
//     image:req.body.file,
//     catagory:req.body.Category ,
//     type:req.body.type

//   };

//   // var values = [loginUserID,req.body.name,req.body.price,req.body.file,req.body.catagory,req.body.type];


  
//   upload(req, res, (err) => {
//     if(err){
//       res.render('serviceProvide', {
//         msg: err ,
//         "Username":loginUserName,
//            "imageaddress":loginUserImage ,
//       });
//     } else {
//       if(req.file == undefined){
//         res.render('serviceProvide', {
//           msg: 'Error: No File Selected!' ,
//           "Username":loginUserName,
//            "imageaddress":loginUserImage ,
//         });
//       } else {
              
        
//         var query = connection.query("INSERT INTO tailorprofile set  VALUES (?) ",data, function(err, rows){
  
//           if(err){
//                console.log(err);
//                return next("Mysql error, check your query");
//           }
 
//           res.render('serviceProvide.ejs',{
//            "result":res,
//            "Username":loginUserName,
//            "imageaddress":loginUserImage ,
           
//        });
//      });
      
//       }}})
  
  
//   });
  




// Here Route Desing End 


app.post('/completehistory',(req,res)=>{
   connection.query("SELECT * FROM `order`  where tailorid="+loginUserID,(error,res2,field)=>{
         res.render('./Order.ejs',{
            "result":res2,
            "Username":loginUserName,
            "imageaddress":loginUserImage
        })
        });
 });


app.get('/:id' ,(req,res)=>{

  // console.log(req.params.id);
  //  console.log(`Now User Name  : ${loginUserName}`)
  //  console.log(`Now User Image  : ${loginUserImage}`)
   connection.query("UPDATE `notification` SET `notificationstatus`= '1'  WHERE `orderidfk` = "+req.params.id+" ",(error,res2,field)=>{

   });
  connection.query("SELECT * FROM `order`  where orderid="+req.params.id,(error,res2,field)=>{

    if (error) {
      console.log("SQL error is here : "+error.sqlMessage);
  }
  var buttonvisibilty =true;
    res.render('notificationdetail.ejs',{
      "Username":loginUserName,
      "imageaddress":loginUserImage,
      "result":res2 ,
      "buttonvisibilty":buttonvisibilty
    });
   });
})
//
// app.post('/OrderForm',(req,res)=>{
//
//    // console.log(` Here is the user id :  ${req.body.dropdown}`);
//               SelectTailorName=req.body.dropdowntailor
//               SelectTailorID=req.body.dropdown;
//
//     res.render('OrderForm.ejs',{
//       "Username":loginUserName,
//       "imageaddress":loginUserImage
//     });
//
// })


let datahanger =function(date){
  var d = new Date(date),
      month = '' + (d.getMonth() + 1),
      day = '' + d.getDate(),
      year = d.getFullYear();

  if (month.length < 2) month = '0' + month;
  if (day.length < 2) day = '0' + day;

  return [year, month, day].join('-');
}

app.post('/Order',(req,res)=>{


  connection.query("SELECT * FROM `order` WHERE `tailorid` = "+loginUserID+" AND `orderStatus`= 'confirm'",
  (error,res2,field)=>{


res.render('OrderTo.ejs', {

  "Username":loginUserName,
  "imageaddress":loginUserImage,
  "result":res2

});
})

})



app.post('/delete',(req,res)=>{

  connection.query("UPDATE `order` SET `orderStatus`= 'deleted'  WHERE `orderid` = "+req.body.orderid+" ",(error,res2,field)=>{


    connection.query("SELECT * FROM `order` WHERE `tailorid` = "+loginUserID+" AND `orderStatus`= 'pendding'",
    (error,res2)=>{

     if (error) {
       console.log("SQL 2 error is here : "+error.sqlMessage);
                }

       res.render('./Order.ejs',{
        "Username":loginUserName,
        "imageaddress":loginUserImage,
        "selecttailorid":SelectTailorID,
        "imageaddress":loginUserImage ,
        "result":res2,

     });
    })



   });

})



app.post('/complete',(req,res)=>{

  console.log('now in penndinf')
connection.query("SELECT * FROM `order` WHERE `tailorid` = "+loginUserID+" AND `orderStatus`= 'completed'",
(error,res2)=>{


 if(error) {
   console.log("SQL 2 error is here : "+error.sqlMessage);
            }

   res.render('./Order.ejs',{
    "Username":loginUserName,
    "imageaddress":loginUserImage,
    "selecttailorid":SelectTailorID,
    "imageaddress":loginUserImage ,
    "result":res2,

 });
})
});

app.post('/cancel',(req,res)=>{
 console.log('Now in cancel order');
connection.query("SELECT * FROM `order` WHERE `tailorid` = "+loginUserID+" AND `orderStatus`= 'cancel'",
(error,res2)=>{
 if (error) {
   console.log("SQL 2 error is here : "+error.sqlMessage);
            }

   res.render('./Order.ejs',{
    "Username":loginUserName,
    "imageaddress":loginUserImage,
    "selecttailorid":SelectTailorID,
    "imageaddress":loginUserImage ,
    "result":res2,

 });
})
});


app.post('/confirm',(req,res)=>{

  // console.log('button click id '+req.body.buttonsubmit);
  // console.log(`nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn ${req.body.currentorderid}`);
   if(req.body.buttonsubmit==="Confirm"){
    let notificationStatus=0;
     var notificationRecord = [loginUserID,loginUserName,nowTimer,req.body.currentuserid,req.body.currentusername,notificationStatus,req.body.currentorderid];

    connection.query("UPDATE `order` SET `orderStatus`= 'confirm'  WHERE `orderid` = "+req.body.currentorderid,(error,res2,field)=>{
    });
    connection.query("INSERT INTO `notification` (`senderid`, `sendername`, `time`,`reciverid`,`recivername`,`notificationstatus`,`orderidfk`) VALUES (?)", [notificationRecord],
    (error,res2)=>{

   if (error) {

      console.log(error.sqlMessage);
   }

    });

   }

   if(req.body.buttonsubmit==="Cancel"){
     let notificationStatus=0;
      var notificationRecord = [loginUserID,loginUserName,nowTimer,req.body.currentuserid,req.body.currentusername,notificationStatus,req.body.currentorderid];

    connection.query("UPDATE `order` SET `orderStatus`= 'cancel'  WHERE `orderid` = "+req.body.currentorderid,(error,res2,field)=>{
    });
    connection.query("INSERT INTO `notification` (`senderid`, `sendername`, `time`,`reciverid`,`recivername`,`notificationstatus`,`orderidfk`) VALUES (?)", [notificationRecord],
    (error,res2)=>{

   if (error) {

      console.log(error.sqlMessage);
   }

    });
  }
    //
    // connection.query("DELETE FROM `notification` WHERE  `orderidfk` = "+req.body.currentorderid,(error,res2,field)=>{
    // });

      res.render('./index.ejs',{
        "Username":loginUserName,
        "imageaddress":loginUserImage,
        "selecttailorid":SelectTailorID,
        "imageaddress":loginUserImage ,
        "totalOrdersend":totalOrder ,
        "penddingordersend":penddingorder ,
        "totalTailorattach":totalTailor ,
        "avgrate":avgratestar
    })

  })

app.post('/orderdetail' ,(req,res)=>{


   let notificationStatus=0;

   var notificationRecord = [loginUserID,loginUserName,nowTimer,req.body.currentuserid,req.body.currentusername,notificationStatus,req.body.orderidfordetail];

     if(req.body.clickbtn==="completed")
      {

        console.log('Compelte order is running')
     connection.query("INSERT INTO `notification` (`senderid`, `sendername`, `time`,`reciverid`,`recivername`,`notificationstatus`,`orderidfk`) VALUES (?)", [notificationRecord],
     (error,res2)=>{
        if(error){
          console.log("Notification error is : "+error.sqlMessage);
        }
        connection.query("UPDATE `order` SET `orderStatus`= 'completed'  WHERE `orderid` = "+req.body.orderidfordetail,(error,res2,field)=>{
          if(error){
            console.log("Update completed  error is : "+error.sqlMessage);
          }
        });
    })




     }



  connection.query("SELECT * FROM `order`  where orderid="+req.body.orderidfordetail,(error,res2,field)=>{

    if (error) {
      console.log("SQL error is here : "+error.sqlMessage);
     }

       var buttonvisibilty =false;
    res.render('notificationdetail.ejs',{
      "Username":loginUserName,
      "imageaddress":loginUserImage,
      "result":res2,
      "buttonvisibilty":buttonvisibilty
    });

   });
})





//app.listen(4000,()=>console.log('Listen at port 4000'));
